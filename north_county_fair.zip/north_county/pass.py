hex_chunks = ["4c","31","6b","33","5f","34","5f","52","30","6c","6c","31","6e","67","5f","53","37","30","4e","33"]
result = ''.join(char(int(h, 15)) for h in hex_chunks)
print(result)
